class HomeController < ApplicationController
  def index
    # 1. Hard‑coded birth date
    birth_date = Date.new(1957, 10, 21)

    # 2. Determine which date to calculate:
    #    - if params[:date] is present, use that
    #    - otherwise default to today
    target = params[:date].present? ? Date.parse(params[:date]) : Date.today

    # 3. Compute numerology without saving
    @result = DailyNumerology.new(birth_date: birth_date)
    @result.send(:compute_numerology)  # populates number, color, etc.
    @display_date = target
    # Re‑compute for the target date instead of today:
    # Temporarily override Date.today inside compute_numerology:
    # (simplest is to pass target into compute, but here we’ll monkey‑patch:)
    Date.stub :today, target do
      @result.send(:compute_numerology)
    end

    # 4. Prepare defaults for the next calculation
    @future_date = params[:date] || Date.today + 1
  end
end


