Rails.application.routes.draw do
    # Landing page
    root "home#index"
  
    # Only allow new/create/show for daily numerology records
    resources :daily_numerologies, only: [:new, :create, :show]
  end
  
